package com.geektech.ytube.core.utils

object Constant {
val putId = "KEY_ID"
}
