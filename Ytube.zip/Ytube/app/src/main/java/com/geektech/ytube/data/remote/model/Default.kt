package com.geektech.ytube.data.remote.model

data class Default(
    val height: Int,
    val url: String,
    val width: Int
)