package com.geektech.ytube.data.remote.model

data class ContentDetails(
    val itemCount: Int
)