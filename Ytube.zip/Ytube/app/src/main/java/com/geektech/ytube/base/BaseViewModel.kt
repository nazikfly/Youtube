package com.geektech.ytube.base

open class BaseViewModel {

}