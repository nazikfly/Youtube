package com.geektech.ytube.data.remote.model

data class Localized(
    val description: String,
    val title: String
)