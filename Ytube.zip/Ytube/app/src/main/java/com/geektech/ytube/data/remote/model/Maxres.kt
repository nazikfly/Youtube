package com.geektech.ytube.data.remote.model

data class Maxres(
    val height: Int,
    val url: String,
    val width: Int
)