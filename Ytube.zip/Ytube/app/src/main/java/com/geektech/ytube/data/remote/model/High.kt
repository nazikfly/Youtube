package com.geektech.ytube.data.remote.model

data class High(
    val height: Int,
    val url: String,
    val width: Int
)