package com.geektech.ytube.data.remote.model

data class PageInfo(
    val resultsPerPage: Int,
    val totalResults: Int
)