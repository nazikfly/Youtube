package com.geektech.ytube.data.remote.model

data class Medium(
    val height: Int,
    val url: String,
    val width: Int
)